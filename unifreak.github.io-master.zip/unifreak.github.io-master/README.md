# Intro

My personal blog, built with Jekyll and Github page.

# If you want to use this theme

1. fork it
2. **Important**: If you want to use [Baidu Statistics][baiduTongji] functionality, remember to replace the content of `/javascripts/baidu_statistics.js` with your own. If you don't want to use it or don't understand what I'm talking about, just comment out line 43 of `/_includes/footer.html`. 
3. **Important**: If you want to use the [Disqus][disqus] (comment system) functionality, remember to replace the content of `/_includes/disqus_load.html` and `/_includes/disqus_count.html` with your own content. If you don't want to use it or don't understand what I'm talking about, just comment out line 27 in `/_layouts/markdownreader_bare.html` and line 35 in `/_layouts/post.html`.
4. Modify `/_config.yml` with your own info, replace `/images/me.png` with your own.

That's it

[baiduTongji]: http://tongji.baidu.com/web/welcome/login
[disqus]: https://disqus.com/
